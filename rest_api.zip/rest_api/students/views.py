from django.shortcuts import render
from rest_framework.decorators import api_view
from students.models import Student
from rest_framework import status
from students.serializers import StudentSerializer
from rest_framework.response import Response


# #READ
# # @api_view(['GET','POST'])
# # # Create your views here.
# # def studentlist(request):
# #     if(request.method=='GET'):
# #         s=Student.objects.all()
# #         stu=StudentSerializer(s,many=True)                      #json format, serialization
# #         return Response(stu.data,status=status.HTTP_200_OK)
# #
#
# #CLASS BASED
#
# from rest_framework.views import APIView
# class studentlistview(APIView):
#
#     #GET
#     def get(self,request):
#         s=Student.objects.all()
#         stu=StudentSerializer(s,many=True)
#         return Response(stu.data,status=status.HTTP_200_OK)
#
# #     #create cheyyan
# #     elif(request.method=='POST'):
# #           s=StudentSerializer(data=request.data)                #json to django, deserialization
# #           if s.is_valid():                                      #checking the assining
# #               s.save()
# #               return Response(s.data,status=status.HTTP_201_CREATED)
# #           return Response(s.errors,status=status.HTTP_400_BAD_REQUEST)
#
# #POST
#     def post(self,request):
#         s=StudentSerializer(data=request.data)
#         if s.is_valid():
#             s.save()
#             return Response(s.data,status=status.HTTP_201_CREATED)
#         return Response(s.errors,status=status.HTTP_400_BAD_REQUEST)
# #
# # #  PRIMARY KEY BASED GET DATA
# # @api_view(['GET','PUT','DELETE'])
# # def student_detail(request,pk):
# #     try:
# #         s=Student.objects.get(id=pk)
# #     except Student.DoesnotExist:
# #         return Response(status=status.HTTP_404_NOT_FOUND)
# #
# #     if(request.method=='GET'):
# #         stu=StudentSerializer(s)
# #         return Response(stu.data,status=status.HTTP_200_OK)
# #
# #     elif(request.method=='PUT'):
# #         stu=StudentSerializer(s,data=request.data)
# #         if stu.is_valid():
# #             stu.save()
# #         return Response(stu.data,status=status.HTTP_201_CREATED)
# #
# #     elif(request.method=='DELETE'):
# #         s.delete()
# #         return Response(status=status.HTTP_204_NO_CONTENT)
#
# #CLASS BASED ID CALLING GET
# from django.http import Http404
# class studentdetailview(APIView):
#     def get_object(self,pk):
#         try:
#             return Student.objects.get(id=pk)
#         except:
#             raise Http404                       #class base le 404 ne raise vech call cheyyam
#     def get(self,request,pk):
#         s=self.get_object(pk)      #class base le geting funtion  (ivide ithu vilikkumbol oru fun koodi create cheyyanam)
#         stu=StudentSerializer(s)
#         return Response(stu.data,status=status.HTTP_200_OK)
#
#     #PUT
#     def put(self,request,pk):
#         s = self.get_object(pk)
#         stu = StudentSerializer(s, data=request.data)
#         if stu.is_valid():
#             stu.save()
#         return Response(stu.data,status=status.HTTP_201_CREATED)
#
#     def delete(self,request,pk):
#         s = self.get_object(pk)
#         s.delete()
#         return Response(status=status.HTTP_204_NO_CONTENT)


#MIXINS

from rest_framework import mixins,generics
# class StudentListView(mixins.ListModelMixin,mixins.CreateModelMixin,generics.GenericAPIView):
#     queryset = Student.objects.all()
#     serializer_class = StudentSerializer
#     def get(self,request):
#         return self.list(request)
#
#     def post(self,request):
#         return self.create(request)
#
# class StudentDetailView(mixins.RetrieveModelMixin,mixins.UpdateModelMixin,mixins.DestroyModelMixin,generics.GenericAPIView):
#     queryset =  Student.objects.all()
#     serializer_class = StudentSerializer
#     def get(self,request,pk):
#         return self.retrieve(request)
#
#     def put(self,request,pk):
#         return self.update(request)
#
#     def delete(self,request,pk):
#         return self.destroy(request)

#GENERICS

# class StudentListView(generics.ListCreateAPIView):
#     queryset = Student.objects.all()
#     serializer_class = StudentSerializer
#
# class StudentDetailView(generics.RetrieveUpdateDestroyAPIView):
#     queryset = Student.objects.all()
#     serializer_class = StudentSerializer




##VIEWSET  #any operation one view koduthal mathy

from rest_framework import viewsets
class StudentListView(viewsets.ModelViewSet):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer



from django.db.models import Q #logical and logical or operation

def searchbooks(request):
    k=None                         #initialize k as None(no value)
    if(request.method=="POST"):
        query=request.POST['q']    #get input key from form
        if query:
            k=Book.objects.filter(Q(title__icontains=query) | Q(author__icontains=query))  #django lookups  #it checks the key in title and author field.
            #filter funtion returns only the matching records., icontains-->anywhere inside the field,   i--->caseinsensive{uppercase and lower case select}
    return render(request,'search.html',{'search':k})